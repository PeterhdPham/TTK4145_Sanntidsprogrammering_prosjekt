package pack

import "fmt"

func Test() {
	fmt.Println("test from pack")
}
